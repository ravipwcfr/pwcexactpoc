<DataServiceKey("UserID")>
Public Class [Me]
	Public Property CurrentDivision As Integer
	Public Property DivisionCustomer As Guid
	Public Property DivisionCustomerCode As String
	Public Property DivisionCustomerName As String
	Public Property FullName As String
	Public Property PictureUrl As String
	Public Property ThumbnailPicture As Byte()
	Public Property ThumbnailPictureFormat As String
	Public Property UserID As Guid
	Public Property UserName As String
	Public Property LanguageCode As String
	Public Property Legislation As Long
	Public Property Email As String
	Public Property Title As String
	Public Property Initials As String
	Public Property FirstName As String
	Public Property MiddleName As String
	Public Property LastName As String
	Public Property Gender As String
	Public Property Nationality As String
	Public Property Language As String
	Public Property Phone As String
	Public Property PhoneExtension As String
	Public Property Mobile As String
	Public Property ServerTime As String
	Public Property ServerUtcOffset As Double
End Class
