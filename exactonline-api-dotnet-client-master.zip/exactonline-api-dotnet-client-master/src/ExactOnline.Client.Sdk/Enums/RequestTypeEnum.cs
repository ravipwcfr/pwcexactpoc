﻿
namespace ExactOnline.Client.Sdk.Enums
{
	public enum RequestTypeEnum
	{
		GET,
		POST,
		PUT,
		DELETE
	}
}
