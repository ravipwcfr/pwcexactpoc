﻿namespace ExactOnline.Client.Sdk.Delegates
{
	public delegate string AccessTokenManagerDelegate();
}
