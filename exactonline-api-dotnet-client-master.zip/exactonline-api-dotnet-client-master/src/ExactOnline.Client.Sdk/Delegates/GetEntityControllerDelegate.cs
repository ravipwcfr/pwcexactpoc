﻿using ExactOnline.Client.Sdk.Controllers;

namespace ExactOnline.Client.Sdk.Delegates
{
	public delegate EntityController GetEntityController(object o);
}
