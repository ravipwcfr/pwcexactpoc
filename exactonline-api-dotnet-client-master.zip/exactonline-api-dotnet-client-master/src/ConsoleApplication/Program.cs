﻿using ExactOnline.Client.Models;
using ExactOnline.Client.Sdk.Controllers;
using System;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Xml.Linq;

namespace ConsoleApplication
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			// These are the authorisation properties of your app.
			// You can find the values in the App Center when you are maintaining the app.
			const string clientId = "a741f9fa-6d4d-4a94-85b2-15e8414c7a6d";
			const string clientSecret = "XukmVgTTK3UF";

			// This can be any url as long as it is identical to the callback url you specified for your app in the App Center.
			var callbackUrl = new Uri("https://project-good-int-az.pwcinternal.com/sitepages/MyDashBoard.aspx"); 

			var connector = new Connector(clientId, clientSecret, callbackUrl);

			getResponse(connector.GetAccessToken());

			Console.ReadLine();
			
		}

		/// <summary>
		/// Method to call the Exact XML APIs to create new user / company in Exact and display API output in console
		/// </summary>
		/// <param name="accessToken"></param>
		static async void getResponse(string accessToken)
		{
			/*--- Create new company in Exact ----*/

			string page = "https://start.exactonline.fr/docs/XMLUpload.aspx?Topic=Administrations&_Division_=21387";
			XDocument addCompanyXmlDoc = XDocument.Load("AddCompanyToExact.xml");
			var httpContent = new StringContent(addCompanyXmlDoc.ToString(), Encoding.UTF8, "application/xml");



			/*--- Create new user in Exact ----*/

			//string page = "https://start.exactonline.fr/docs/XMLUpload.aspx?Topic=Users&_Division_=21387";
			//XDocument addUserXmlDoc = XDocument.Load("AddUsersToExact.xml");
			//var httpContent = new StringContent(addUserXmlDoc.ToString(), Encoding.UTF8, "application/xml");



			HttpClient client = new HttpClient();
			client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);


			using (HttpResponseMessage response = await client.PostAsync(page, httpContent))


			using (HttpContent content = response.Content)
			{

				// ... Read the string.
				string result = await content.ReadAsStringAsync();

				// ... Display the result.
				if (result != null &&
				result.Length >= 50)
				{
					Console.WriteLine(result);
				}
			}

		}
	}
}
