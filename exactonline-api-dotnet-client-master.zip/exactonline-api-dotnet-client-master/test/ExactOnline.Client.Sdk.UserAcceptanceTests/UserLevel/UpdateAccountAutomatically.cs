﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExactOnline.Client.Sdk.UserAcceptanceTests.UserLevel
{
	[TestClass]
	public class UpdateAccountAutomatically184246
	{
		[TestMethod, Ignore]
		[TestCategory("User Acceptance Tests")]
		public void UpdateAccountAutomatically()
		{
			//var toc = new TestObjectsCreator();
			//APIConnection conn = new APIConnection(toc.ApiConnector(), toc.UriCrmAccount());
			//Controller ac = new Controller(conn);

			//// Get Account from EOL to alter
			//var accounts = ac.Get("Name+eq+'Test Name UAT2'");
			//var testAccount = (Account)accounts[0];
			//Guid testAccountGuid = testAccount.ID;

			//// Alter name of the testaccount
			//testAccount.Name = "Test Name Auto Update";
			//System.Threading.Thread.Sleep(5000); // In this time the controller must update the entity itself

			//var updatedAccount = (Account)ac.GetEntity(testAccountGuid.ToString());
			//if (!updatedAccount.Name.Equals("Test Name Auto Update"))
			//{
			//	throw new Exception("The Account is not automatically updated");
			//}

			throw new Exception("This functionality is not implemented yet");
		}
	}
}
